BookCollector
================

Main Functions:
----------------
- scan book's 二维码
- display books's info: ISBN, 书名，价格，作者
- Python export sqlite to csv

Note:
-----
QR scan实现参考自代码：http://dldx.csdn.net/fd.php?i=428159902193072&s=0439db332c818f36f57060e6778c2e65

