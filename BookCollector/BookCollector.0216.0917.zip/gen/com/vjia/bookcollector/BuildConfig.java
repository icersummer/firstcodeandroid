/** Automatically generated file. DO NOT MODIFY */
package com.vjia.bookcollector;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}